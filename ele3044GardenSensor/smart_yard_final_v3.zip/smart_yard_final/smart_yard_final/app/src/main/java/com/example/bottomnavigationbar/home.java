package com.example.bottomnavigationbar;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link home#newInstance} factory method to
 * create an instance of this fragment.
 */

public class home extends Fragment {

    TextView scoreOne, scoreTwo, plantOneConstraint, plantTwoConstraint, scoreTotal;
    View mulchieImage, totalScoreConstraint;
    hubData plantOne = new hubData("12345");
    hubData plantTwo = new hubData("12346");

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        String total_s = getResources().getString(R.string.total_score_text);
        ProgressBar progressBar = (ProgressBar) view.findViewById(R.id.progress_bar);
        scoreOne = view.findViewById(R.id.some_id);
        scoreTwo = view.findViewById(R.id.some_id2);
        scoreTotal = view.findViewById(R.id.some_id7);
        plantOneConstraint = view.findViewById(R.id.plantOneConstraint);
        plantTwoConstraint = view.findViewById(R.id.plantOneConstraint2);
        totalScoreConstraint = view.findViewById(R.id.rectangle_6);
        mulchieImage = view.findViewById(R.id.image_4);
        progressBar.setProgress(Integer.parseInt(total_s));
        if (plantOne.autoUpdate()){
            scoreOne.setText(String.valueOf(plantOne.get_score()));
            if (plantOne.get_score() < 33){
                plantOneConstraint.setBackgroundResource(R.drawable.box_red);
            }
            else if (plantOne.get_score() < 66){
                plantOneConstraint.setBackgroundResource(R.drawable.box_yellow);
            }
            else{
                plantOneConstraint.setBackgroundResource(R.drawable.box_green);
            }
        }
        if (plantTwo.autoUpdate()){
            scoreTwo.setText(String.valueOf(plantTwo.get_score()));
            if (plantTwo.get_score() < 33){
                plantTwoConstraint.setBackgroundResource(R.drawable.box_red);
            }
            else if (plantTwo.get_score() < 66){
                plantTwoConstraint.setBackgroundResource(R.drawable.box_yellow);
            }
            else{
                plantTwoConstraint.setBackgroundResource(R.drawable.box_green);
            }
        }

        // Calculate Total Score
        int total_score = (plantOne.get_score() + plantTwo.get_score())/2;
        scoreTotal.setText(String.valueOf(total_score));
        progressBar.setProgress(total_score);
        if (total_score < 33){
            mulchieImage.setBackgroundResource(R.drawable.sad);
            totalScoreConstraint.setBackgroundResource(R.drawable.total_score_red);
        }
        else if (total_score < 66){
            mulchieImage.setBackgroundResource(R.drawable.mid);
            totalScoreConstraint.setBackgroundResource(R.drawable.total_score_yellow);
        }
        else{
            mulchieImage.setBackgroundResource(R.drawable.joy);
            totalScoreConstraint.setBackgroundResource(R.drawable.total_score_green);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

}