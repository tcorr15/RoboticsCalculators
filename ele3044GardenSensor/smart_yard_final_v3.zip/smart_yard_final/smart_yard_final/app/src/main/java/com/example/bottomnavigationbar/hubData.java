package com.example.bottomnavigationbar;
import org.json.JSONException;
import org.json.JSONObject;

public class hubData {
    private double _temp = 0.0;
    private int _humid = 0;
    private int _moist = 0;
    private int _light = 0;
    private int _score = 0;
    private String _euid;
    private String JSON_STRING = HttpUtils.getContents("https://192.168.0.20/db_view.php");

    public hubData(){
        _euid = "null";
        _temp = 0;
        _humid = 0;
        _moist = 0;
        _light = 0;
        _score = 0;
    }

    public hubData(String euid){
        _euid = euid;
    }

    public double get_temp(){
        return _temp;
    }

    public int get_humid(){
        return _humid;
    }

    public int get_moist(){
        return _moist;
    }

    public int get_light(){
        return _light;
    }

    public int get_score(){
        return _score;
    }

    public String get_euid(){
        return _euid;
    }

    public boolean autoUpdate(){
        try {
            JSONObject obj = new JSONObject(JSON_STRING);
            JSONObject input = obj.getJSONObject(_euid);
            _score = Integer.parseInt(input.getString("score"));
            _temp = Double.parseDouble(input.getString("temp"));
            _moist = Integer.parseInt(input.getString("moisture"));
            _light = Integer.parseInt(input.getString("uv"));
            _humid = Integer.parseInt(input.getString("humidity"));
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }
}

